void func1();
void func2();
void func3();

void func1() {
	int a=1;
	func2();
}
void func2() {
	int a=2;
	func3();
}
void func3() {
	int a=3;
}
int main() {
	int a=0;
	func1();
}